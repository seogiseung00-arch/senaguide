window.DEFAULT_DATA = {
  version: 10,
  siteTitle: 'RE:BORN GUIDE ARCHIVE',
  heroOrder: [
    '리나','에반','비스킷','미호','나타','클로에','루리','오를리','라이언','선란',
    '돼오','태오','레이첼','지크','타카','풍연','샤오','헤브니아','파이','세인','소교','파스칼',
    '유이','백룡','카론','데이지','에스파다','여포','관우','이주희','조운','밀리아','바네사',
    '란드그리드','칼헤론','린','레긴레이프','각성 아일린',
    '하연','스쿨드','윤건','아일린','동영','오르카','연희'
  ],
  portraits: {
    '리나':'assets/portraits/rina.jpg','에반':'assets/portraits/evan.jpg','비스킷':'assets/portraits/biscuit.jpg',
    '미호':'assets/portraits/miho.jpg','나타':'assets/portraits/nata.jpg','풍연':'assets/portraits/pungyeon.jpg',
    '레이첼':'assets/portraits/rachel.jpg','라이언':'assets/portraits/ryan.jpg','선란':'assets/portraits/seonran.jpg',
    '샤오':'assets/portraits/xiao.jpg','헤브니아':'assets/portraits/heavenia.jpg','파이':'assets/portraits/pie.jpg',
    '세인':'assets/portraits/sein.jpg','소교':'assets/portraits/sogyo.jpg','파스칼':'assets/portraits/pascal.jpg',
    '클로에':'assets/portraits/chloe.jpg','루리':'assets/portraits/ruri.jpg','오를리':'assets/portraits/orly.jpg',
    '돼오':'assets/portraits/dwaeo.jpg','태오':'assets/portraits/teo.jpg','지크':'assets/portraits/jake.jpg','타카':'assets/portraits/taka.jpg',
    '유이':'assets/portraits/yui.jpg','백룡':'assets/portraits/baekryong.jpg','카론':'assets/portraits/karon.jpg',
    '데이지':'assets/portraits/daisy.jpg','에스파다':'assets/portraits/espada.jpg','여포':'assets/portraits/yeopo.jpg',
    '관우':'assets/portraits/guanyu.jpg','이주희':'assets/portraits/leejuhee.jpg','조운':'assets/portraits/zhaoyun.jpg',
    '밀리아':'assets/portraits/milia.jpg','바네사':'assets/portraits/vanessa.jpg','란드그리드':'assets/portraits/landgrid.jpg',
    '칼헤론':'assets/portraits/kalheron.jpg','린':'assets/portraits/rin.jpg','레긴레이프':'assets/portraits/reginleif.jpg',
    '각성 아일린':'assets/portraits/awakened_aileen.jpg',
    '하연':'https://channeln.gcdn.netmarble.com/channeln/Upload/4f5320c5-9075-4a77-8ad8-44c53dd24d7b.jpg',
    '스쿨드':'https://hedwig-cf.netmarble.com/forum-common/tskgb/sena_rebirth/thumbnail/932ed9b486bd4853a71aa61e2d5943da_1779344871481_d.jpg',
    '윤건':'https://channeln.gcdn.netmarble.com/channeln/Upload/59ed999d-b613-4563-b24b-1fd0c13f7807.jpg',
    '아일린':'assets/portraits/aileen.jpg',
    '동영':'https://img.gamewith.net/img/original_ad433b57182617c025a56cb8a8893f1b.png',
    '오르카':'https://static.inven.co.kr/column/2026/06/25/news/i1586767581.jpg',
    '연희':'https://hedwig-cf.netmarble.com/forum-common/tskgb/sena_rebirth/thumbnail/bea07a6a0cfc4e21a82baef746942441_1749685660618_d.jpg'
  },
  petImages: {
    '제오':'assets/pets/jeo.jpg',
    '윈디':'assets/pets/windy.jpg',
    '연지':'assets/pets/yeonji.jpg',
    '이린':'assets/pets/irin.jpg',
    '코리':'assets/pets/kori.jpg'
  },
  heroRoles: {
    '리나':'지원형','에반':'방어형','비스킷':'지원형','미호':'마법형','나타':'마법형',
    '클로에':'지원형','루리':'마법형','오를리':'지원형','라이언':'공격형','선란':'공격형',
    '돼오':'공격형','태오':'공격형','레이첼':'만능형','지크':'만능형','타카':'공격형',
    '풍연':'공격형','샤오':'공격형','헤브니아':'공격형','파이':'공격형','세인':'공격형',
    '소교':'마법형','파스칼':'마법형','유이':'지원형','백룡':'공격형','카론':'지원형',
    '데이지':'마법형','에스파다':'마법형','여포':'공격형','관우':'만능형','이주희':'지원형',
    '조운':'공격형','밀리아':'마법형','바네사':'마법형','란드그리드':'공격형','칼헤론':'공격형',
    '린':'마법형','레긴레이프':'마법형','각성 아일린':'만능형',
    '하연':'지원형','스쿨드':'마법형','윤건':'마법형','아일린':'만능형','동영':'마법형','오르카':'공격형','연희':'마법형'
  },
  utilityPages: {
    pvp: {
      title: 'PVP',
      heading: 'PVP 공략 준비 중',
      body: ''
    },
    daily: {
      title: '일일보상',
      heading: '매일매일 일일 선물',
      buttonLabel: '일일보상 받으러 가기 ↗',
      buttonUrl: 'https://skre-shop.netmarble.com/ko/event/daily_gift'
    },
    coupons: {
      title: '쿠폰함',
      buttonLabel: '쿠폰 입력 사이트 열기 ↗',
      buttonUrl: 'https://sena-coupon.vercel.app/'
    }
  },
  heroProfiles: {},
  couponCodes: [
    {code:'SKRE300BIRTH', reward:'4성 전반 선택권, 영웅 위시 300장, 펫 위시 30장, 빛스강 3개, 골드 300만, 노랑정수 30개', note:'별도 공지'},
    {code:'7KSUMMERRUBY', reward:'1000 루비', note:'별도 공지'},
    {code:'7KSUMMERFEST', reward:'펫 소환권 5장', note:'별도 공지'},
    {code:'SUMMERTIME7K', reward:'영웅 위시 5장', note:'별도 공지'},
    {code:'7KREKIMETSUNOYAIBA', reward:'영웅 위시 10장', note:''},
    {code:'7enmugen', reward:'영웅 위시 20장 · 조율의 결정 400개', note:''}
  ],
  categories: {
    siege: { name:'공성전', short:'공성전', eyebrow:'PVE / SIEGE', icon:'◇', description:'요일별 공성전 세팅과 스킬 순서', accent:'#d6ad55' },
    raid: { name:'레이드', short:'레이드', eyebrow:'PVE / RAID', icon:'◎', description:'일반 레이드 보스별 세팅과 스킬 순서', accent:'#69a7dd' },
    emergency: { name:'돌발레이드', short:'돌발레이드', eyebrow:'PVE / EMERGENCY RAID', icon:'◇', description:'보스별 고스펙·저스펙 세팅', accent:'#e17474' },
    expedition: { name:'강림원정대', short:'강림원정대', eyebrow:'PVE / EXPEDITION', icon:'⚔', description:'강림원정대 1라·2라 세팅과 스킬 순서', accent:'#83b676' },
    destroy: { name:'파괴신', short:'파괴신', eyebrow:'PVE / DESTROY GOD', icon:'✦', description:'파괴신 1라·2라 세팅과 스킬 순서', accent:'#a6a6a6' },
    trial: { name:'시련의 탑', short:'시련의 탑', eyebrow:'PVE / TRIAL TOWER', icon:'▱', description:'시련의 탑 공략', emptyMessage:'추후 업데이트 예정', accent:'#9c8a63' },
    pvp: { name:'PVP', short:'PVP', eyebrow:'PVP / ARENA', icon:'⚔', description:'결투장 세팅과 스킬 순서', accent:'#c85f5f' }
  },
  guides: [
    {id:'siege-mon-rudy-basic',category:'siege',group:'월요일',boss:'루디',variant:'기본',title:'월요일 · 루디',order:10,sourceImage:'assets/guides/siege/siege_01.png',skillImage:'assets/skills/siege/mon_rudy_basic.jpg',heroes:['리나','에반','비스킷','미호','나타'],tags:['월요일','루디','기본','공성전','성기사','수문장','복수자']},
    {id:'siege-tue-aileen-basic',category:'siege',group:'화요일',boss:'아일린',variant:'기본',title:'화요일 · 아일린',order:20,sourceImage:'assets/guides/siege/siege_05.png',skillImage:'assets/skills/siege/tue_aileen_basic.jpg',heroes:['클로에','리나','비스킷','미호','나타'],tags:['화요일','아일린','기본','공성전']},
    {id:'siege-tue-aileen-alt',category:'siege',group:'화요일',boss:'아일린',variant:'다른 버전',title:'화요일 · 아일린',order:21,sourceImage:'assets/guides/siege/siege_06.png',skillImage:'assets/skills/siege/tue_aileen_alt.jpg',heroes:['클로에','리나','비스킷','미호','루리'],tags:['화요일','아일린','다른버전','공성전']},
    {id:'siege-wed-rachel-orly',category:'siege',group:'수요일',boss:'레이첼',variant:'오를리 버전',title:'수요일 · 레이첼',order:30,sourceImage:'assets/guides/siege/siege_07.png',skillImage:'assets/skills/siege/wed_rachel_orly.jpg',heroes:['오를리','라이언','비스킷','미호','루리'],tags:['수요일','레이첼','오를리버전','공성전']},
    {id:'siege-wed-rachel-nata',category:'siege',group:'수요일',boss:'레이첼',variant:'나타 버전',title:'수요일 · 레이첼',order:31,sourceImage:'assets/guides/siege/siege_08.png',skillImage:'assets/skills/siege/wed_rachel_nata.jpg',heroes:['리나','라이언','비스킷','미호','나타'],tags:['수요일','레이첼','나타버전','공성전']},
    {id:'siege-wed-rachel-rina-stable',category:'siege',group:'수요일',boss:'레이첼',variant:'리나 안정형 · 현재 미사용',title:'수요일 · 레이첼',order:32,sourceImage:'assets/guides/siege/siege_09.png',skillImage:'assets/skills/siege/wed_rachel_rina_stable.jpg',heroes:['리나','라이언','비스킷','미호','나타'],tags:['수요일','레이첼','리나안정형','현재미사용','공성전']},
    {id:'siege-thu-dellons-basic',category:'siege',group:'목요일',boss:'델론즈',variant:'기본',title:'목요일 · 델론즈',order:40,sourceImage:'assets/guides/siege/siege_10.png',skillImage:'assets/skills/siege/thu_dellons_basic.jpg',heroes:['돼오','레이첼','비스킷','라이언','선란'],tags:['목요일','델론즈','기본','공성전']},
    {id:'siege-fri-jave-basic',category:'siege',group:'금요일',boss:'제이브',variant:'기본',title:'금요일 · 제이브',order:50,sourceImage:'assets/guides/siege/siege_11.png',skillImage:'assets/skills/siege/fri_jave_basic.jpg',heroes:['지크','레이첼','비스킷','라이언','타카'],tags:['금요일','제이브','기본','공성전']},
    {id:'siege-sat-spike-basic',category:'siege',group:'토요일',boss:'스파이크',variant:'기본',title:'토요일 · 스파이크',order:60,sourceImage:'assets/guides/siege/siege_12.png',skillImage:'assets/skills/siege/sat_spike_basic.jpg',heroes:['풍연','레이첼','비스킷','라이언','타카'],tags:['토요일','스파이크','기본','공성전']},
    {id:'siege-sat-spike-seonran',category:'siege',group:'토요일',boss:'스파이크',variant:'선란 버전',title:'토요일 · 스파이크',order:61,sourceImage:'assets/guides/siege/siege_02.png',skillImage:'assets/skills/siege/sat_spike_seonran.jpg',heroes:['풍연','레이첼','비스킷','라이언','선란'],tags:['토요일','스파이크','선란버전','공성전']},
    {id:'siege-sun-kris-basic',category:'siege',group:'일요일',boss:'크리스',variant:'기본',title:'일요일 · 크리스',order:70,sourceImage:'assets/guides/siege/siege_04.png',skillImage:'assets/skills/siege/sun_kris_basic.jpg',heroes:['샤오','미호','비스킷','소교','파스칼'],tags:['일요일','크리스','기본','공성전']},
    {id:'siege-sun-kris-alt',category:'siege',group:'일요일',boss:'크리스',variant:'다른 버전',title:'일요일 · 크리스',order:71,sourceImage:'assets/guides/siege/siege_03.png',skillImage:'assets/skills/siege/sun_kris_alt.jpg',heroes:['샤오','헤브니아','비스킷','파이','세인'],tags:['일요일','크리스','다른버전','공성전']},

    {id:'raid-ruin-eye',category:'raid',group:'파멸의 눈동자',boss:'파멸의 눈동자',variant:'',title:'파멸의 눈동자',order:10,sourceImage:'assets/guides/raid/ruin_eye.png',skillImage:'assets/skills/raid/ruin_eye.jpg',heroes:['유이','선란','비스킷','지크','백룡'],tags:['레이드','파멸의 눈동자','성기사','복수자','수문장']},
    {id:'raid-steel-predator',category:'raid',group:'강철의 포식자',boss:'강철의 포식자',variant:'',title:'강철의 포식자',order:20,sourceImage:'assets/guides/raid/steel_predator.png',skillImage:'assets/skills/raid/steel_predator.jpg',heroes:['미호','선란','비스킷','소교','파스칼'],tags:['레이드','강철의 포식자','복수자','수문장']},
    {id:'raid-wooma',category:'raid',group:'우마왕',boss:'우마왕',variant:'',title:'우마왕',order:30,sourceImage:'assets/guides/raid/wooma.png',skillImage:'assets/skills/raid/wooma.jpg',heroes:['카론','비스킷','오를리','데이지','에스파다'],tags:['레이드','우마왕','선봉장','수문장','성기사','복수자']},

    {id:'emergency-leonid-high',category:'emergency',group:'레오니드',boss:'레오니드',variant:'고스펙',title:'레오니드',order:10,sourceImage:'assets/guides/emergency/leonid_high.png',skillImage:'assets/skills/emergency/leonid_high.jpg',heroes:['여포','관우','비스킷','샤오','백룡'],tags:['돌발레이드','레오니드','고스펙','복수자','수문장','암살자']},
    {id:'emergency-leonid-low',category:'emergency',group:'레오니드',boss:'레오니드',variant:'저스펙',title:'레오니드',order:11,sourceImage:'assets/guides/emergency/leonid_low.png',skillImage:'assets/skills/emergency/leonid_low.jpg',heroes:['여포','관우','비스킷','샤오','백룡'],tags:['돌발레이드','레오니드','저스펙','복수자','수문장','암살자']},
    {id:'emergency-astrea-high',category:'emergency',group:'아스트레아',boss:'아스트레아',variant:'고스펙',title:'아스트레아',order:20,sourceImage:'assets/guides/emergency/astrea_high.png',skillImage:'assets/skills/emergency/astrea_high.jpg',heroes:['이주희','비스킷','미호','에스파다','데이지'],tags:['돌발레이드','아스트레아','고스펙','건강의 반지','수문장','복수자']},
    {id:'emergency-astrea-low',category:'emergency',group:'아스트레아',boss:'아스트레아',variant:'저스펙',title:'아스트레아',order:21,sourceImage:'assets/guides/emergency/astrea_low.png',skillImage:'assets/skills/emergency/astrea_low.jpg',heroes:['카론','비스킷','오를리','에스파다','데이지'],tags:['돌발레이드','아스트레아','저스펙','건강의 반지','수문장','복수자']},
    {id:'emergency-kalista-high',category:'emergency',group:'칼리스트라',boss:'칼리스트라',variant:'고스펙',title:'칼리스트라',order:30,sourceImage:'assets/guides/emergency/kalista_high.png',skillImage:'assets/skills/emergency/kalista_high.jpg',heroes:['조운','라이언','레이첼','비스킷','세인'],tags:['돌발레이드','칼리스트라','고스펙','복수자','수문장']},
    {id:'emergency-kalista-low',category:'emergency',group:'칼리스트라',boss:'칼리스트라',variant:'저스펙',title:'칼리스트라',order:31,sourceImage:'assets/guides/emergency/kalista_low.png',skillImage:'assets/skills/emergency/kalista_low.jpg',heroes:['조운','라이언','샤오','비스킷','세인'],tags:['돌발레이드','칼리스트라','저스펙','복수자','수문장']},

    {id:'expedition-yeonhui-r1',category:'expedition',group:'연희',boss:'연희',variant:'1라',title:'연희',order:10,sourceImage:'assets/guides/expedition/yeonhui_r1.png',skillImage:'assets/skills/expedition/yeonhui_r1.jpg',originalImage:'assets/originals/expedition_yeonhui_full.png',heroes:['클로에','밀리아','바네사','오를리','루리'],tags:['강림원정대','연희','1라']},
    {id:'expedition-yeonhui-r2',category:'expedition',group:'연희',boss:'연희',variant:'2라',title:'연희',order:11,sourceImage:'assets/guides/expedition/yeonhui_r2.png',skillImage:'assets/skills/expedition/yeonhui_r2.jpg',originalImage:'assets/originals/expedition_yeonhui_full.png',heroes:['미호','리나','비스킷','데이지','나타'],tags:['강림원정대','연희','2라']},
    {id:'expedition-karma-r1',category:'expedition',group:'카르마',boss:'카르마',variant:'1라',title:'카르마',order:20,sourceImage:'assets/guides/expedition/karma_r1.png',skillImage:'assets/skills/expedition/karma_r1.jpg',originalImage:'assets/originals/expedition_karma_full.png',heroes:['란드그리드','선란','칼헤론','타카','풍연'],tags:['강림원정대','카르마','1라']},
    {id:'expedition-karma-r2',category:'expedition',group:'카르마',boss:'카르마',variant:'2라',title:'카르마',order:21,sourceImage:'assets/guides/expedition/karma_r2.png',skillImage:'assets/skills/expedition/karma_r2.jpg',originalImage:'assets/originals/expedition_karma_full.png',heroes:['관우','레이첼','비스킷','여포','라이언'],tags:['강림원정대','카르마','2라']},
    {id:'expedition-kyle-r1',category:'expedition',group:'카일',boss:'카일',variant:'1라',title:'카일',order:30,sourceImage:'assets/guides/expedition/kyle_r1.png',skillImage:'assets/skills/expedition/kyle_r1.jpg',originalImage:'assets/originals/expedition_kyle_full.png',heroes:['관우','레이첼','여포','란드그리드','세인'],tags:['강림원정대','카일','1라']},
    {id:'expedition-kyle-r2',category:'expedition',group:'카일',boss:'카일',variant:'2라',title:'카일',order:31,sourceImage:'assets/guides/expedition/kyle_r2.png',skillImage:'assets/skills/expedition/kyle_r2.jpg',originalImage:'assets/originals/expedition_kyle_full.png',heroes:['헤브니아','리나','비스킷','파이','백룡'],tags:['강림원정대','카일','2라']},
    {id:'expedition-teo-r1',category:'expedition',group:'태오',boss:'태오',variant:'1라',title:'태오',order:40,sourceImage:'assets/guides/expedition/teo_r1.png',skillImage:'assets/skills/expedition/teo_r1.jpg',originalImage:'assets/originals/expedition_teo_full.png',heroes:['린','리나','바네사','에스파다','파스칼'],tags:['강림원정대','태오','1라']},
    {id:'expedition-teo-r2',category:'expedition',group:'태오',boss:'태오',variant:'2라',title:'태오',order:41,sourceImage:'assets/guides/expedition/teo_r2.png',skillImage:'assets/skills/expedition/teo_r2.jpg',originalImage:'assets/originals/expedition_teo_full.png',heroes:['오를리','비스킷','미호','데이지','소교'],tags:['강림원정대','태오','2라']},

    {id:'destroy-r1',category:'destroy',group:'파괴신',boss:'파괴신',variant:'1라',title:'파괴신',order:10,sourceImage:'assets/guides/destroy/r1.png',skillImage:'assets/skills/destroy/r1.jpg',originalImage:'assets/originals/destroy_full.png',heroes:['선란','미호','레긴레이프','소교','파스칼'],tags:['파괴신','1라','복수자']},
    {id:'destroy-r2',category:'destroy',group:'파괴신',boss:'파괴신',variant:'2라',title:'파괴신',order:11,sourceImage:'assets/guides/destroy/r2.png',skillImage:'assets/skills/destroy/r2.jpg',originalImage:'assets/originals/destroy_full.png',heroes:['샤오','각성 아일린','비스킷','헤브니아','세인'],tags:['파괴신','2라','복수자','수문장']},

    {id:'pvp-arena-01',category:'pvp',group:'결투장',boss:'결투장',variant:'마덱',title:'마덱',order:10,sourceImage:'',skillImage:'',skillSequence:[
      {label:'1',name:'스쿨드 위',image:'assets/skills/pvp/skuld_up.jpg'},
      {label:'2',name:'윤건 위',image:'assets/skills/pvp/yoongeon_up.jpg'},
      {label:'3',name:'윤건 아래',image:'assets/skills/pvp/yoongeon_down.jpg'}
    ],heroes:['하연','스쿨드','윤건','아일린','동영'],tags:['PVP','결투장','하연','스쿨드','윤건','아일린','동영','보호진형']},
    {id:'pvp-attack-02',category:'pvp',group:'결투장',boss:'결투장',variant:'공덱',title:'공덱',order:20,sourceImage:'',skillImage:'',skillSequence:[
      {label:'1',name:'아일린 위',image:'assets/skills/pvp/aileen_up_attack.jpg'},
      {label:'2',name:'하연 위',image:'assets/skills/pvp/hayeon_up_attack.jpg'},
      {label:'3',name:'선란 위',image:'assets/skills/pvp/seonran_up_attack.jpg'}
    ],heroes:['오르카','칼헤론','하연','아일린','선란'],tags:['PVP','결투장','공덱','오르카','칼헤론','하연','선란','아일린','보호진형']},
    {id:'pvp-seonran-yoongeon-03',category:'pvp',group:'결투장',boss:'결투장',variant:'선란윤건덱',title:'선란윤건덱',order:30,sourceImage:'',skillImage:'',skillSequence:[
      {label:'1',name:'윤건 위',image:'assets/skills/pvp/yoongeon_up_sy.jpg'},
      {label:'2',name:'연희 위',image:'assets/skills/pvp/yeonhee_up_sy.jpg'},
      {label:'3',name:'윤건 아래',image:'assets/skills/pvp/yoongeon_down_sy.jpg'}
    ],heroes:['하연','동영','윤건','연희','선란'],tags:['PVP','결투장','선란윤건덱','하연','동영','윤건','연희','선란','공격진형']}
  ]
};
