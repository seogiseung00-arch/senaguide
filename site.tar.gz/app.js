(() => {
  'use strict';

  const STORAGE_KEY = 'rebornGuideArchiveStateV10';
  const LEGACY_STORAGE_KEYS = ['rebornGuideArchiveStateV9','rebornGuideArchiveStateV8','rebornGuideArchiveStateV7','rebornGuideArchiveStateV6'];
  const EDIT_PASSWORD = '2810';
  const ui = {
    main: document.getElementById('mainContent'),
    nav: document.getElementById('primaryNav'),
    breadcrumbs: document.getElementById('breadcrumbs'),
    editToggle: document.getElementById('editToggle'),
    editToggleText: document.getElementById('editToggleText'),
    modePill: document.getElementById('modePill'),
    saveBar: document.getElementById('saveBar'),
    saveButton: document.getElementById('saveButton'),
    discardButton: document.getElementById('discardButton'),
    trashNav: document.getElementById('trashNav'),
    trashCount: document.getElementById('trashCount'),
    search: document.getElementById('globalSearch'),
    searchResults: document.getElementById('searchResults'),
    menuButton: document.getElementById('menuButton'),
    scrim: document.getElementById('scrim'),
    modal: document.getElementById('imageModal'),
    modalImage: document.getElementById('modalImage'),
    modalTitle: document.getElementById('modalTitle'),
    modalClose: document.getElementById('modalClose'),
    zoomIn: document.getElementById('zoomIn'),
    zoomOut: document.getElementById('zoomOut'),
    zoomLabel: document.getElementById('zoomLabel'),
    toast: document.getElementById('toast')
  };

  const clone = (obj) => JSON.parse(JSON.stringify(obj));
  let state = loadState();
  hydrateHeroProfiles();
  hydrateGuideDetails();
  hydrateUtilityPages();
  let persistedSnapshot = JSON.stringify(state);
  let editMode = false;
  let dirty = false;
  let currentCategoryFilter = '';
  let heroSearchComposing = false;
  let globalSearchComposing = false;
  let localHeroFilter = '';
  let localHeroRoleFilter = '전체';
  let guideTabs = {};
  let pvpOpenGuideId = '';
  let modalZoom = 100;
  let draggingGuide = null;
  let draggingHero = null;

  function loadState() {
    try {
      let raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        for (const key of LEGACY_STORAGE_KEYS) {
          raw = localStorage.getItem(key);
          if (raw) break;
        }
      }
      if (!raw) return clone(window.DEFAULT_DATA);
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return clone(window.DEFAULT_DATA);
      const defaults = clone(window.DEFAULT_DATA);
      const defaultHeroOrder = clone(window.DEFAULT_DATA.heroOrder || []);
      const defaultPortraits = clone(window.DEFAULT_DATA.portraits || {});
      const defaultHeroRoles = clone(window.DEFAULT_DATA.heroRoles || {});
      const defaultPetImages = clone(window.DEFAULT_DATA.petImages || {});
      const merged = Object.assign(defaults, parsed);
      merged.version = window.DEFAULT_DATA.version;
      merged.heroOrder = [...new Set([...(parsed.heroOrder || []), ...defaultHeroOrder])];
      merged.portraits = Object.assign({}, defaultPortraits, parsed.portraits || {});
      merged.heroRoles = Object.assign({}, defaultHeroRoles, parsed.heroRoles || {});
      merged.petImages = Object.assign({}, defaultPetImages, parsed.petImages || {});
      // v10: 사용자가 지정한 새 쿠폰 6종으로 한 번 교체. v10에서 편집한 뒤에는 그대로 유지.
      if ((Number(parsed.version) || 0) < 10) merged.couponCodes = clone(window.DEFAULT_DATA.couponCodes || []);
      merged.categories = Object.assign({}, clone(window.DEFAULT_DATA.categories || {}), parsed.categories || {});
      const utilityDefaults = clone(window.DEFAULT_DATA.utilityPages || {});
      const savedUtility = parsed.utilityPages || {};
      merged.utilityPages = {};
      Object.keys(utilityDefaults).forEach(key => {
        merged.utilityPages[key] = Object.assign({}, utilityDefaults[key] || {}, savedUtility[key] || {});
      });
      const defaultGuides = clone(window.DEFAULT_DATA.guides || []);
      const savedGuides = Array.isArray(parsed.guides) ? parsed.guides : [];
      const savedById = new Map(savedGuides.map(g => [g.id, g]));
      const defaultIds = new Set(defaultGuides.map(g => g.id));
      merged.guides = defaultGuides.map(g => {
        const saved = savedById.get(g.id);
        if (!saved) return g;
        const details = Object.assign({}, g.details || {}, saved.details || {});
        if (g.category === 'pvp' && (g.details?.pets || []).length && !(saved.details?.pets || []).length) details.pets = clone(g.details.pets);
        return Object.assign({}, g, saved, { details });
      });
      savedGuides.filter(g => !defaultIds.has(g.id)).forEach(g => merged.guides.push(g));
      return merged;
    } catch (e) {
      return clone(window.DEFAULT_DATA);
    }
  }

  function hydrateHeroProfiles() {
    state.heroProfiles ||= {};
    state.heroOrder ||= [];
    state.portraits ||= {};
    state.heroRoles ||= clone(window.DEFAULT_DATA.heroRoles || {});
    const discovered = new Set(state.heroOrder);
    state.guides.forEach(g => (g.heroes || []).forEach(h => discovered.add(h)));
    discovered.forEach(name => {
      if (!state.heroOrder.includes(name)) state.heroOrder.push(name);
      if (!state.heroProfiles[name]) {
        state.heroProfiles[name] = {
          basicSetup: '미등록',
          exclusiveEquipment: '미등록',
          transcendence: '미등록',
          notes: '미등록'
        };
      }
    });
  }

  function hydrateGuideDetails() {
    state.guides ||= [];
    state.guides.forEach(g => {
      g.details ||= {};
      g.details.rows ||= (g.heroes || []).map(hero => ({ hero, formation:'', weapon:[], armor:[], accessory:'', alternative:'', sub:'', speed:'', comment:'' }));
      g.details.rows.forEach((r, i) => {
        r.hero ||= (g.heroes || [])[i] || '';
        r.formation ||= '';
        r.weapon = Array.isArray(r.weapon) ? r.weapon : [r.weapon].filter(Boolean);
        r.armor = Array.isArray(r.armor) ? r.armor : [r.armor].filter(Boolean);
        r.accessory ||= ''; r.alternative ||= ''; r.sub ||= ''; r.speed ||= ''; r.comment ||= '';
        r.colors = (r.colors && typeof r.colors === 'object') ? r.colors : {};
      });
      if (!Array.isArray(g.details.pets)) g.details.pets = [];
      if (!Array.isArray(g.details.altPets)) g.details.altPets = [];
    });
  }

  function hydrateUtilityPages() {
    state.utilityPages ||= clone(window.DEFAULT_DATA.utilityPages || {});
    const defaults = window.DEFAULT_DATA.utilityPages || {};
    Object.keys(defaults).forEach(key => {
      state.utilityPages[key] = Object.assign({}, clone(defaults[key] || {}), state.utilityPages[key] || {});
    });
    state.couponCodes ||= clone(window.DEFAULT_DATA.couponCodes || []);
  }

  function markDirty() {
    dirty = true;
    ui.saveBar.classList.remove('hidden');
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      persistedSnapshot = JSON.stringify(state);
      dirty = false;
      ui.saveBar.classList.add('hidden');
      showToast('변경사항을 저장했습니다.', 'success');
    } catch (e) {
      showToast('브라우저 저장 공간이 부족합니다. 큰 이미지 교체는 서버 저장소 연결 후 사용하는 것이 안전합니다.', 'warn');
    }
  }

  function discardChanges() {
    state = JSON.parse(persistedSnapshot);
    hydrateHeroProfiles();
    hydrateGuideDetails();
    hydrateUtilityPages();
    dirty = false;
    ui.saveBar.classList.add('hidden');
    render();
    showToast('저장 전 변경사항을 되돌렸습니다.');
  }

  function resetToSource() {
    if (!confirm('사이트의 로컬 편집 내용을 모두 초기 데이터로 되돌릴까요?')) return;
    state = clone(window.DEFAULT_DATA);
    hydrateHeroProfiles();
    hydrateGuideDetails();
    hydrateUtilityPages();
    try { localStorage.removeItem(STORAGE_KEY); LEGACY_STORAGE_KEYS.forEach(key => localStorage.removeItem(key)); } catch (_) {}
    persistedSnapshot = JSON.stringify(state);
    dirty = false;
    ui.saveBar.classList.add('hidden');
    render();
    showToast('초기 제공 데이터로 복원했습니다.', 'success');
  }

  function showToast(message, kind='') {
    ui.toast.textContent = message;
    ui.toast.className = `toast ${kind}`.trim();
    ui.toast.classList.remove('hidden');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => ui.toast.classList.add('hidden'), 2600);
  }

  function escapeHtml(value='') {
    return String(value)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }

  function routeTo(hash) {
    location.hash = hash;
    document.body.classList.remove('sidebar-open');
  }

  function getRoute() {
    const hash = decodeURIComponent(location.hash || '#heroes');
    if (hash.startsWith('#hero/')) return {type:'hero', name: hash.slice(6)};
    if (hash.startsWith('#guide/')) return {type:'guide', id: hash.slice(7)};
    if (hash === '#trash') return {type:'trash'};
    if (hash === '#pvp') return {type:'pvp'};
    if (hash === '#daily') return {type:'daily'};
    if (hash === '#coupons') return {type:'coupons'};
    const key = hash.replace('#','');
    if (key === 'heroes' || !key) return {type:'heroes'};
    if (state.categories[key]) return {type:'category', category:key};
    return {type:'heroes'};
  }

  function renderNav() {
    const route = getRoute();
    const activeCategory = route.type === 'guide'
      ? (state.guides.find(g => g.id === route.id)?.category || '')
      : route.category;
    const items = [
      {key:'heroes', label:'캐릭터 도감', icon:'♙', hash:'#heroes'},
      ...Object.entries(state.categories).filter(([key]) => key !== 'pvp').map(([key,c]) => ({key,label:c.short,icon:c.icon,hash:`#${key}`})),
      {key:'pvp', label:'PVP', icon:'⚔', hash:'#pvp'},
      {key:'daily', label:'일일보상', icon:'◷', hash:'#daily'},
      {key:'coupons', label:'쿠폰함', icon:'▣', hash:'#coupons'}
    ];
    ui.nav.innerHTML = items.map(item => {
      const active = (route.type === 'heroes' && item.key === 'heroes') || activeCategory === item.key || route.type === item.key;
      return `<button type="button" class="nav-item ${active?'active':''}" data-route="${item.hash}">
        <span class="nav-icon">${item.icon}</span><span class="nav-item-label">${escapeHtml(item.label)}</span>
      </button>`;
    }).join('');

    const deletedCount = state.guides.filter(g => g.deleted).length;
    ui.trashCount.textContent = deletedCount;
    ui.trashNav.classList.toggle('hidden', !editMode);
    ui.trashNav.classList.toggle('active', route.type === 'trash');
  }

  function renderBreadcrumbs(parts) {
    ui.breadcrumbs.innerHTML = parts.map((p,i) => i === parts.length-1 ? `<b>${escapeHtml(p)}</b>` : escapeHtml(p)).join(' &nbsp;›&nbsp; ');
  }

  function getHeroUses(name) {
    return state.guides.filter(g => !g.deleted && (g.heroes || []).includes(name)).sort((a,b) => categoryIndex(a.category)-categoryIndex(b.category) || a.order-b.order);
  }

  function categoryIndex(key) {
    return Object.keys(state.categories).indexOf(key);
  }

  function portrait(name) {
    return state.portraits[name] || '';
  }

  function renderHeroes() {
    renderBreadcrumbs(['ARCHIVE','캐릭터 도감']);
    const all = state.heroOrder.filter(name => state.heroProfiles[name]);
    const roles = ['공격형','마법형','방어형','지원형','만능형'];
    const q = localHeroFilter.trim().toLowerCase();
    const filtered = all.filter(name => {
      const role = state.heroRoles?.[name] || '미분류';
      const roleMatch = localHeroRoleFilter === '전체' || role === localHeroRoleFilter;
      const textMatch = !q || name.toLowerCase().includes(q) || role.toLowerCase().includes(q) || getHeroUses(name).some(g => (`${g.title} ${g.variant} ${g.boss}`).toLowerCase().includes(q));
      return roleMatch && textMatch;
    });
    ui.main.innerHTML = `
      <div class="page-head hero-page-head">
        <div>
          <div class="eyebrow">DATABASE / HEROES</div>
          <h1 class="page-title">캐릭터 도감</h1>
          <p class="page-description">캐릭터를 누르면 세팅 정보와 사용처를 확인할 수 있습니다.</p>
        </div>
        <div class="page-actions">
          ${editMode?'<button class="button ghost" data-action="reset-source">초기 데이터 복원</button>':''}
        </div>
      </div>
      ${editMode?'<div class="inline-editor-note">편집 모드가 켜져 있습니다. 캐릭터 순서는 카드를 끌어서 바꿀 수 있고, 세부 정보는 캐릭터를 눌러 현재 화면에서 바로 수정합니다.</div>':''}
      <section class="surface hero-directory">
        <div class="section-head"><h2>등록 캐릭터</h2><span class="count-badge">${filtered.length}/${all.length}</span></div>
        <div class="hero-directory-controls">
          <label class="hero-search-field">
            <span class="hero-filter-label">검색</span>
            <input id="heroLocalSearch" class="local-search" type="search" value="${escapeHtml(localHeroFilter)}" placeholder="캐릭터 이름 입력" autocomplete="off" />
          </label>
          <div class="hero-role-filter-block">
            <span class="hero-filter-label">유형</span>
            <div class="hero-role-filters">
              ${['전체',...roles].map(role=>`<button class="hero-role-filter ${localHeroRoleFilter===role?'active':''}" type="button" data-hero-role-filter="${role}">${role}</button>`).join('')}
            </div>
          </div>
        </div>
        <div id="heroGrid" class="hero-grid">
          ${filtered.map(name => heroCardHtml(name)).join('') || '<div class="empty-state" style="grid-column:1/-1">검색 결과가 없습니다.</div>'}
        </div>
      </section>`;

    const input = document.getElementById('heroLocalSearch');
    if (input) {
      const applyLocalSearch = (value) => {
        localHeroFilter = value;
        const y = window.scrollY;
        renderHeroes();
        requestAnimationFrame(()=>{
          window.scrollTo(0,y);
          const x=document.getElementById('heroLocalSearch');
          if(x){x.focus(); const end=x.value.length; try{x.setSelectionRange(end,end);}catch(_){}}
        });
      };
      input.addEventListener('compositionstart', () => { heroSearchComposing = true; });
      input.addEventListener('compositionend', e => { heroSearchComposing = false; applyLocalSearch(e.target.value); });
      input.addEventListener('input', e => { if(heroSearchComposing || e.isComposing) return; applyLocalSearch(e.target.value); });
    }
  }

  function heroCardHtml(name) {
    const img = portrait(name);
    const role = state.heroRoles?.[name] || '미분류';
    const roleClass = ({'공격형':'attack','마법형':'magic','방어형':'defense','지원형':'support','만능형':'universal'})[role] || 'unknown';
    return `<article class="hero-card compact" data-hero="${escapeHtml(name)}" data-route="#hero/${encodeURIComponent(name)}" ${editMode?'draggable="true"':''}>
      <span class="hero-edit-handle" title="드래그로 순서 변경">⋮⋮</span>
      <div class="hero-image-wrap">${img?`<img src="${img}" alt="${escapeHtml(name)}">`:`<div class="search-result-icon" style="width:100%;height:100%;border:0;border-radius:50%;font-size:28px">${escapeHtml(name.slice(0,1))}</div>`}</div>
      <div class="hero-card-body">
        <div class="hero-name">${escapeHtml(name)}</div>
        <span class="hero-role-badge ${roleClass}">${escapeHtml(role)}</span>
      </div>
    </article>`;
  }

  function renderHeroDetail(name) {
    if (!state.heroProfiles[name]) { routeTo('#heroes'); return; }
    const p = state.heroProfiles[name];
    const uses = getHeroUses(name);
    const pveGroups = {};
    uses.forEach(g => { (pveGroups[g.category] ||= []).push(g); });
    renderBreadcrumbs(['ARCHIVE','캐릭터 도감',name]);
    ui.main.innerHTML = `
      <div class="page-head">
        <div>
          <div class="eyebrow">DATABASE / HERO</div>
          <h1 class="page-title">${escapeHtml(name)}</h1>
          <p class="page-description">캐릭터 단위 정보와 현재 등록된 공략 사용처를 연결합니다.</p>
        </div>
        <div class="page-actions">
          <button class="button ghost" data-route="#heroes">← 도감</button>
          ${editMode?`<button class="button" data-action="replace-hero-portrait" data-hero="${escapeHtml(name)}">초상화 교체</button><button class="button" data-action="rename-hero" data-hero="${escapeHtml(name)}">이름 변경</button>`:''}
        </div>
      </div>
      ${editMode?'<div class="inline-editor-note">텍스트를 클릭해서 바로 수정하세요. 수정 후 아래 저장 바의 <b>저장</b>을 누르면 됩니다.</div>':''}
      <div class="hero-detail-grid">
        <aside class="surface hero-profile-card">
          ${portrait(name)?`<img class="hero-profile-image" src="${portrait(name)}" alt="${escapeHtml(name)}">`:`<div class="hero-profile-image" style="display:grid;place-items:center;font-size:42px">${escapeHtml(name.slice(0,1))}</div>`}
          <div class="hero-profile-name">${escapeHtml(name)}</div>
          <p class="hero-profile-sub">${escapeHtml(state.heroRoles?.[name] || '미분류')}</p>
          <div class="hero-profile-stat"><span>PVE 사용처</span><b>${uses.length}</b></div>
          <div class="hero-profile-stat"><span>PVP 사용처</span><b>미등록</b></div>
        </aside>
        <div class="hero-detail-stack">
          <section class="surface info-card">
            <h3>캐릭터 기본 정보</h3>
            <div class="info-grid">
              ${heroInfoField(name,'basicSetup','기본 세팅',p.basicSetup)}
              ${heroInfoField(name,'exclusiveEquipment','전용장비 옵션',p.exclusiveEquipment)}
              ${heroInfoField(name,'transcendence','초월 추천',p.transcendence)}
            </div>
          </section>
          <section class="surface info-card">
            <h3>메모</h3>
            <div class="info-field">
              <div class="info-field-label">관리 메모</div>
              <div class="info-field-value" ${editMode?`contenteditable="true" data-hero-field="notes" data-hero="${escapeHtml(name)}"`:''}>${escapeHtml(p.notes || '미등록')}</div>
            </div>
          </section>
          <section class="surface info-card">
            <h3>사용처</h3>
            <div class="usage-tabs"><div class="usage-tab active">PVE <b>${uses.length}</b></div><div class="usage-tab">PVP <b>0</b></div></div>
            ${uses.length ? Object.entries(pveGroups).map(([cat, list]) => usageGroupHtml(cat,list)).join('') : '<div class="empty-state">등록된 PVE 사용처가 없습니다.</div>'}
            <div style="height:10px"></div>
            <div class="empty-state">PVP 사용처는 결투장 자료 제공 후 연결됩니다.</div>
          </section>
        </div>
      </div>`;
  }

  function heroInfoField(name, field, label, value) {
    return `<div class="info-field"><div class="info-field-label">${label}</div><div class="info-field-value" ${editMode?`contenteditable="true" data-hero-field="${field}" data-hero="${escapeHtml(name)}"`:''}>${escapeHtml(value || '미등록')}</div></div>`;
  }

  function usageGroupHtml(category, list) {
    const c = state.categories[category];
    return `<div style="margin:12px 0 7px;font-size:11px;color:#8398b0;font-weight:750">${escapeHtml(c.name)}</div>
      <div class="usage-list">${list.map(g => `<button class="usage-link" type="button" data-route="#guide/${encodeURIComponent(g.id)}"><span class="usage-mark" style="color:${c.accent}">${c.icon}</span><span class="usage-copy"><span class="usage-title">${escapeHtml(g.title)}${g.variant?` · ${escapeHtml(g.variant)}`:''}</span><span class="usage-meta">${escapeHtml(c.name)} → 바로 이동</span></span></button>`).join('')}</div>`;
  }

  function getFormationType(g) {
    const rows = g.details?.rows || [];
    const front = rows.filter(r => r.formation === '앞줄').length;
    const back = rows.filter(r => r.formation === '뒷줄').length;
    const inferred = front === 4 && back === 1 ? '보호진형'
      : front === 3 && back === 2 ? '밸런스진형'
      : front === 2 && back === 3 ? '기본진형'
      : front === 1 && back === 4 ? '공격진형'
      : '진형 확인 필요';
    const name = (g.details?.formationType || '').trim() || inferred;
    const className = name === '보호진형' ? 'protect'
      : name === '밸런스진형' ? 'balance'
      : name === '기본진형' ? 'basic'
      : name === '공격진형' ? 'attack' : 'unknown';
    return {name, front, back, className};
  }

  function formationEditorHtml(g, f) {
    if (!editMode) return `<b>${escapeHtml(f.name)}</b>`;
    const options = ['', '보호진형', '밸런스진형', '기본진형', '공격진형'];
    const selected = (g.details?.formationType || '').trim();
    return `<select class="formation-editor" data-formation-select aria-label="진형 선택">${options.map(v => `<option value="${escapeHtml(v)}" ${selected===v?'selected':''}>${escapeHtml(v || `자동 판정 · ${f.name}`)}</option>`).join('')}</select>`;
  }

  function utilityEditableAttrs(page, field) {
    return editMode ? `contenteditable="true" data-utility-page="${page}" data-utility-field="${field}"` : '';
  }

  function pvpHeroToken(hero, lane='') {
    const img = portrait(hero);
    return `<div class="pvp-hero-token ${escapeHtml(lane)}" title="${escapeHtml(hero)}">
      ${img ? `<img src="${img}" alt="${escapeHtml(hero)}">` : `<span class="pvp-avatar-fallback">${escapeHtml(hero.slice(0,1))}</span>`}
      <b>${escapeHtml(hero)}</b>
    </div>`;
  }

  function pvpDeckCardHtml(g) {
    const f = getFormationType(g);
    const rows = g.details?.rows || [];
    const front = rows.filter(r => r.formation === '앞줄');
    const back = rows.filter(r => r.formation === '뒷줄');
    const pet = (g.details?.pets || [])[0] || '';
    const petImg = state.petImages?.[pet] || '';
    const opened = pvpOpenGuideId === g.id;
    return `<article class="pvp-deck-card ${opened?'active':''}">
      <div class="pvp-deck-head">
        <div><span class="pvp-deck-kicker">ARENA DECK</span><h2>${escapeHtml(g.title || g.variant || 'PVP 덱')}</h2></div>
        <span class="pvp-formation-tag ${f.className}">${escapeHtml(f.name)}</span>
      </div>
      <div class="pvp-field">
        <div class="pvp-lane pvp-back-lane"><span class="pvp-lane-label">뒷줄</span>${back.map(r=>pvpHeroToken(r.hero,'back')).join('')}</div>
        <div class="pvp-lane pvp-front-lane"><span class="pvp-lane-label">앞줄</span>${front.map(r=>pvpHeroToken(r.hero,'front')).join('')}</div>
        <div class="pvp-pet-panel">
          <span class="pvp-pet-label">PET</span>
          ${petImg ? `<img src="${petImg}" alt="${escapeHtml(pet)}">` : `<div class="pvp-pet-fallback">✦</div>`}
          <b>${escapeHtml(pet || '미등록')}</b>
        </div>
      </div>
      <button class="pvp-setting-button" type="button" data-pvp-open="${escapeHtml(g.id)}">ⓘ ${opened?'세팅 닫기':'세팅 확인'}</button>
    </article>`;
  }

  function renderPvp() {
    const c = state.categories.pvp;
    const guides = state.guides.filter(g => g.category === 'pvp' && !g.deleted).sort((a,b)=>a.order-b.order);
    if (pvpOpenGuideId && !guides.some(g=>g.id===pvpOpenGuideId)) pvpOpenGuideId = '';
    const selected = guides.find(g=>g.id===pvpOpenGuideId);
    renderBreadcrumbs(['ARCHIVE','PVP']);
    ui.main.innerHTML = `
      <div class="page-head compact-page-head">
        <div><div class="eyebrow">${escapeHtml(c.eyebrow)}</div><h1 class="page-title">PVP</h1><p class="page-description">덱 구성을 먼저 보고, 세팅 확인을 누르면 상세 장비와 스킬 순서를 펼쳐볼 수 있습니다.</p></div>
      </div>
      <div class="pvp-deck-grid">${guides.map(pvpDeckCardHtml).join('')}</div>
      ${selected ? `<div class="pvp-detail-wrap">${guideCardHtml(selected, selected.id)}</div>` : ''}
      ${editMode ? `<button class="add-card pvp-add-guide" type="button" data-action="add-guide" data-category="pvp"><span>＋ PVP 덱 추가</span></button>` : ''}`;
  }

  function renderDaily() {
    const p = state.utilityPages.daily;
    renderBreadcrumbs(['ARCHIVE', p.title || '일일보상']);
    ui.main.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">DAILY REWARD</div><h1 class="page-title" ${utilityEditableAttrs('daily','title')}>${escapeHtml(p.title || '일일보상')}</h1></div></div>
      <section class="surface utility-page utility-link-card">
        <div class="placeholder-icon">◷</div>
        <h2 ${utilityEditableAttrs('daily','heading')}>${escapeHtml(p.heading || '매일매일 일일 선물')}</h2>
        <a class="button primary utility-big-button utility-external-link" href="${escapeHtml(p.buttonUrl || '#')}" target="_blank" rel="noopener noreferrer">
          <span ${utilityEditableAttrs('daily','buttonLabel')}>${escapeHtml(p.buttonLabel || '일일보상 받으러 가기 ↗')}</span>
        </a>
        ${editMode ? `<label class="utility-url-editor"><span>링크 주소</span><input type="url" data-utility-url-page="daily" value="${escapeHtml(p.buttonUrl || '')}" spellcheck="false"></label>` : ''}
      </section>`;
  }

  function renderCoupons() {
    const p = state.utilityPages.coupons;
    renderBreadcrumbs(['ARCHIVE', p.title || '쿠폰함']);
    const coupons = state.couponCodes || [];
    ui.main.innerHTML = `
      <div class="page-head coupon-page-head">
        <div><div class="eyebrow">COUPON BOX</div><h1 class="page-title" ${utilityEditableAttrs('coupons','title')}>${escapeHtml(p.title || '쿠폰함')}</h1></div>
        <a class="button ghost utility-external-link" href="${escapeHtml(p.buttonUrl || '#')}" target="_blank" rel="noopener noreferrer">
          <span ${utilityEditableAttrs('coupons','buttonLabel')}>${escapeHtml(p.buttonLabel || '쿠폰 입력 사이트 열기 ↗')}</span>
        </a>
      </div>
      ${editMode ? `<label class="utility-url-editor coupon-url-editor"><span>쿠폰 입력 사이트 주소</span><input type="url" data-utility-url-page="coupons" value="${escapeHtml(p.buttonUrl || '')}" spellcheck="false"></label>` : ''}
      <section class="surface coupon-hub">
        ${editMode?`<div class="coupon-editor-toolbar"><button class="button primary coupon-add-top" type="button" data-action="add-coupon">＋ 새 쿠폰 추가</button><span>추가 후 코드와 보상을 바로 수정하고 저장하세요.</span></div>`:''}
        <div class="coupon-list">${coupons.map((c,i)=>`<article class="coupon-card">
          <div class="coupon-copy">
            <code ${editMode?`contenteditable="true" data-coupon-field="code" data-coupon-index="${i}"`:''}>${escapeHtml(c.code)}</code>
            <strong ${editMode?`contenteditable="true" data-coupon-field="reward" data-coupon-index="${i}"`:''}>${escapeHtml(c.reward||'')}</strong>
            ${(c.note || editMode)?`<span class="coupon-note ${!c.note?'muted':''}" ${editMode?`contenteditable="true" data-coupon-field="note" data-coupon-index="${i}"`:''}>${escapeHtml(c.note || '—')}</span>`:''}
          </div>
          <div class="coupon-actions">
            <button class="button coupon-copy-button" type="button" data-copy-coupon-index="${i}">복사</button>
            ${editMode?`<button class="button small danger" type="button" data-action="delete-coupon" data-coupon-index="${i}">삭제</button>`:''}
          </div>
        </article>`).join('')}</div>
      </section>`;
  }

  function copyText(value) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(value);
    }
    return new Promise((resolve, reject) => {
      const ta = document.createElement('textarea');
      ta.value = value; ta.setAttribute('readonly','');
      ta.style.position='fixed'; ta.style.opacity='0'; ta.style.pointerEvents='none';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy') ? resolve() : reject(new Error('copy failed')); }
      catch (e) { reject(e); }
      finally { ta.remove(); }
    });
  }

  function renderCategory(category, focusId='') {
    const c = state.categories[category];
    if (!c) { routeTo('#heroes'); return; }
    renderBreadcrumbs(['ARCHIVE',c.name]);
    const all = state.guides.filter(g => g.category === category && !g.deleted).sort((a,b)=>a.order-b.order);
    const groups = [...new Set(all.map(g=>g.group))];

    const focusedGuide = focusId ? all.find(g=>g.id===focusId) : null;
    if (focusedGuide) {
      currentCategoryFilter = focusedGuide.group;
      guideTabs[`${category}|${focusedGuide.group}`] = focusedGuide.id;
    }
    if (!groups.includes(currentCategoryFilter)) currentCategoryFilter = groups[0] || '';

    const groupGuides = all.filter(g=>g.group===currentCategoryFilter);
    const tabKey = `${category}|${currentCategoryFilter}`;
    let selectedId = guideTabs[tabKey];
    if (!groupGuides.some(g=>g.id===selectedId)) selectedId = groupGuides[0]?.id || '';
    if (selectedId) guideTabs[tabKey] = selectedId;
    const selectedGuide = groupGuides.find(g=>g.id===selectedId) || groupGuides[0];

    const primaryTabs = groups.length > 1 ? `<div class="category-filters primary-group-tabs">
      ${groups.map(g=>`<button class="filter-chip ${currentCategoryFilter===g?'active':''}" data-category-filter="${escapeHtml(g)}">${escapeHtml(g)}</button>`).join('')}
    </div>` : '';
    const variantTabs = groupGuides.length > 1 ? `<div class="variant-tabs" aria-label="${escapeHtml(currentCategoryFilter)} 세팅 선택">
      ${groupGuides.map((g,i)=>`<button class="variant-tab ${selectedGuide?.id===g.id?'active':''}" type="button" data-guide-tab="${escapeHtml(g.id)}">${escapeHtml(g.variant || `세팅 ${i+1}`)}</button>`).join('')}
    </div>` : '';

    ui.main.innerHTML = `
      <div class="page-head compact-page-head">
        <div>
          <div class="eyebrow">${escapeHtml(c.eyebrow)}</div>
          <h1 class="page-title">${escapeHtml(c.name)}</h1>
          <p class="page-description">${escapeHtml(c.description || '세팅과 스킬 예약 순서를 한 화면에서 확인할 수 있습니다.')}</p>
        </div>
        <div class="page-actions">${editMode?'<button class="button ghost" data-action="reset-source">초기 데이터 복원</button>':''}</div>
      </div>
      ${editMode?'<div class="inline-editor-note">현재 보이는 표를 직접 수정할 수 있습니다. 스킬 이미지는 아래 편집 버튼에서 교체할 수 있습니다.</div>':''}
      ${primaryTabs}
      ${variantTabs}
      <div id="guideGrid" class="guide-grid">
        ${selectedGuide ? guideCardHtml(selectedGuide, focusId) : `<div class="empty-state category-empty">${escapeHtml(c.emptyMessage || '등록된 공략이 없습니다.')}</div>`}
        ${editMode?`<button class="add-card" type="button" data-action="add-guide" data-category="${category}"><span>＋ 현재 카테고리에 공략 추가</span></button>`:''}
      </div>`;

  }

  function guideCardHtml(g, focusId='') {
    const c = state.categories[g.category];
    const source = g.sourceImageOverride || g.sourceImage;
    const skill = g.skillImageOverride || g.skillImage;
    const hasSkillSequence = Array.isArray(g.skillSequence) && g.skillSequence.length > 0;
    const rows = g.details?.rows || [];
    const petHtml = guidePetsHtml(g);
    return `<article id="guide-${escapeHtml(g.id)}" class="guide-card ${focusId===g.id?'focused':''}" data-guide-id="${escapeHtml(g.id)}" ${editMode?'draggable="true"':''}>
      <header class="guide-card-header">
        <div class="guide-title-wrap">
          <div class="guide-kicker" ${editMode?'contenteditable="true" data-guide-field="group"':''}>${escapeHtml(g.group || c.name)}</div>
          <div class="guide-title" ${editMode?'contenteditable="true" data-guide-field="title"':''}>${escapeHtml(g.title)}</div>
          ${g.variant || editMode ? `<div class="guide-variant" ${editMode?'contenteditable="true" data-guide-field="variant"':''}>${escapeHtml(g.variant || '버전 입력')}</div>`:''}
        </div>
        <div class="guide-card-actions">
          ${(() => { const f=getFormationType(g); return `<div class="guide-formation ${f.className}"><span>진형</span>${formationEditorHtml(g,f)}<small>앞 ${f.front} · 뒤 ${f.back}</small></div>`; })()}
          ${editMode?'<button type="button" class="button small ghost drag-handle" title="드래그해서 순서 변경">↕ 순서</button>':''}
        </div>
      </header>
      ${petHtml}
      <section class="setting-section">
        <div class="setting-section-head"><h3>영웅별 세팅표</h3><span class="count-badge">${rows.length} HEROES</span></div>
        ${settingsTableHtml(g)}
      </section>
      <section class="skill-order-section">
        <div class="setting-section-head"><h3>스킬 예약 순서</h3>${skill && !hasSkillSequence?`<button type="button" class="button small ghost" data-open-image="${skill}" data-image-title="${escapeHtml(g.title)} · 스킬 예약 순서">확대 보기</button>`:''}</div>
        ${skillPanelHtml(g, skill)}
      </section>
      <div class="guide-edit-toolbar">
        <button class="button small" type="button" data-action="edit-heroes" data-guide="${escapeHtml(g.id)}">영웅 목록 편집</button>
        ${hasSkillSequence ? g.skillSequence.map((step,i)=>`<button class="button small" type="button" data-action="replace-image" data-guide="${escapeHtml(g.id)}" data-kind="skill-seq-${i}">스킬 ${i+1} 교체</button>`).join('') : `<button class="button small" type="button" data-action="replace-image" data-guide="${escapeHtml(g.id)}" data-kind="skill">스킬 이미지 교체</button>`}
        ${(g.skillImageOverride || (hasSkillSequence && g.skillSequence.some(step=>step.imageOverride)))?`<button class="button small ghost" type="button" data-action="reset-images" data-guide="${escapeHtml(g.id)}">스킬 이미지 원본 복원</button>`:''}
        <button class="button small danger" type="button" data-action="delete-guide" data-guide="${escapeHtml(g.id)}">삭제</button>
        ${hasSkillSequence ? g.skillSequence.map((step,i)=>`<input class="hidden" type="file" accept="image/*" data-file-input="${escapeHtml(g.id)}-skill-seq-${i}">`).join('') : `<input class="hidden" type="file" accept="image/*" data-file-input="${escapeHtml(g.id)}-skill">`}
      </div>
    </article>`;
  }

  function guidePetsHtml(g) {
    const pets = g.details?.pets || [];
    const alts = g.details?.altPets || [];
    if (!pets.length && !alts.length && !editMode) return '';
    const petText = pets.join(', ');
    const altText = alts.join(', ');
    const thumbs = (names=[]) => names.map(name => {
      const src = state.petImages?.[name] || '';
      return src ? `<span class="guide-pet-icon-wrap" title="${escapeHtml(name)}"><img class="guide-pet-thumb" src="${src}" alt="${escapeHtml(name)}"><small>${escapeHtml(name)}</small></span>` : '';
    }).join('');
    return `<div class="guide-pets">
      <span class="guide-pets-label">추천펫</span>
      <span class="guide-pet-icons">${thumbs(pets)}</span>
      <span class="guide-pets-value ${!petText?'muted':''}" ${editMode?'contenteditable="true" data-guide-meta-field="pets"':''}>${escapeHtml(petText || '미등록')}</span>
      <span class="guide-pets-label secondary">대체펫</span>
      <span class="guide-pet-icons">${thumbs(alts)}</span>
      <span class="guide-pets-value ${!altText?'muted':''}" ${editMode?'contenteditable="true" data-guide-meta-field="altPets"':''}>${escapeHtml(altText || '미등록')}</span>
    </div>`;
  }

  function settingsTableHtml(g) {
    const rows = g.details?.rows || [];
    if (!rows.length) return '<div class="empty-state">등록된 세팅 데이터가 없습니다.</div>';
    return `<div class="settings-table-wrap"><table class="settings-table">
      <thead><tr><th>영웅</th><th>무기 · 옵션 2</th><th>방어구 · 옵션 2</th><th>장신구</th><th>다른 버전</th><th>부옵</th><th>속공</th><th>코멘트</th></tr></thead>
      <tbody>${rows.map((r,i)=>settingRowHtml(g,r,i)).join('')}</tbody>
    </table></div>`;
  }

  function speedClass(value='') {
    const v = String(value).replace(/\s/g,'');
    if (!v) return 'speed-empty';
    if (/^1(?:순위|~)/.test(v)) return 'speed-top';
    if (/^[23]|2~3|2~4|1~3/.test(v)) return 'speed-mid';
    return 'speed-low';
  }

  function commentClass(value='') {
    if (!value) return 'comment-empty';
    return /(필수|죽|빼|낮아|높게|안됨|안 됨|않|변경|주의|권장)/.test(value) ? 'comment-alert' : 'comment-note';
  }

  function settingRowHtml(g, r, rowIndex) {
    const heroImg = portrait(r.hero);
    r.colors = (r.colors && typeof r.colors === 'object') ? r.colors : {};
    const editable = (field, value, optionIndex=null, extraClass='') => {
      const attrs = editMode ? `contenteditable="true" data-setting-field="${field}" data-setting-row="${rowIndex}"${optionIndex===null?'':` data-setting-option="${optionIndex}"`}` : '';
      const display = value || '—';
      return `<div class="setting-value ${extraClass} ${!value?'muted':''}" ${attrs}>${escapeHtml(display)}</div>`;
    };
    const optionStack = (field, values=[]) => {
      const normalized = values.length ? values : ['', ''];
      const two = [normalized[0] || '', normalized[1] || ''];
      return `<div class="option-stack">${two.map((v,j)=>`<div class="option-pill ${!v?'muted':''}" ${editMode?`contenteditable="true" data-setting-field="${field}" data-setting-row="${rowIndex}" data-setting-option="${j}"`:''}>${escapeHtml(v || '—')}</div>`).join('')}</div>`;
    };
    const altColor = r.colors.alternative || '#c8a65a';
    const colorPalette = ['#c8a65a','#5ea5cf','#65b9a7','#c86d68','#9b83c7','#7dae6b'];
    const altPalette = editMode ? `<div class="cell-color-palette" aria-label="다른 버전 색상 선택">${colorPalette.map(color=>`<button type="button" class="cell-color-swatch ${altColor.toLowerCase()===color.toLowerCase()?'active':''}" data-setting-color="${color}" data-setting-color-field="alternative" data-setting-row="${rowIndex}" style="--swatch:${color}" title="${color}"></button>`).join('')}</div>` : '';
    return `<tr>
      <td class="hero-setting-cell"><div class="hero-setting-wrap">
        ${heroImg?`<button class="hero-setting-avatar" type="button" data-route="#hero/${encodeURIComponent(r.hero)}"><img src="${heroImg}" alt="${escapeHtml(r.hero)}"></button>`:''}
        <div><div class="hero-setting-name" ${editMode?`contenteditable="true" data-setting-field="hero" data-setting-row="${rowIndex}"`:''}>${escapeHtml(r.hero)}</div><div class="formation-badge" ${editMode?`contenteditable="true" data-setting-field="formation" data-setting-row="${rowIndex}"`:''}>${escapeHtml(r.formation || '—')}</div></div>
      </div></td>
      <td>${optionStack('weapon', r.weapon)}</td>
      <td>${optionStack('armor', r.armor)}</td>
      <td>${editable('accessory', r.accessory)}</td>
      <td class="alternative-cell ${r.alternative?'has-alt':''}" style="--alt-accent:${altColor}">${editable('alternative', r.alternative, null, 'alternative-value')}${altPalette}</td>
      <td>${editable('sub', r.sub)}</td>
      <td class="speed-cell ${speedClass(r.speed)}">${editable('speed', r.speed)}</td>
      <td class="comment-cell ${commentClass(r.comment)}">${editable('comment', r.comment)}</td>
    </tr>`;
  }

  function skillPanelHtml(g, src) {
    if (Array.isArray(g.skillSequence) && g.skillSequence.length) {
      return `<div class="pvp-skill-sequence">${g.skillSequence.map((step,i)=>{
        const imageSrc = step.imageOverride || step.image || '';
        return `<button class="skill-sequence-step" type="button" ${imageSrc?`data-open-image="${imageSrc}" data-image-title="${escapeHtml(step.name || `스킬 ${i+1}`)}"`:''} title="${escapeHtml(step.name || '')}">
          ${imageSrc?`<img src="${imageSrc}" alt="스킬 ${i+1}">`:`<span class="skill-missing">이미지 없음</span>`}
          <span class="skill-sequence-number">${escapeHtml(step.label || String(i+1))}</span>
        </button>`;
      }).join('')}</div>`;
    }
    if (!src) return `<div class="skill-image-wrap"><div class="empty-state">스킬순서 이미지가 없습니다.${editMode?' 아래 편집 버튼에서 등록할 수 있습니다.':''}</div></div>`;
    return `<div class="skill-image-wrap"><img src="${src}" alt="${escapeHtml(g.title)} 스킬 예약 순서" data-open-image="${src}" data-image-title="${escapeHtml(g.title)} · ${escapeHtml(g.variant||'')} · 스킬 예약 순서"></div>`;
  }

  function renderTrash() {
    if (!editMode) { routeTo('#heroes'); return; }
    renderBreadcrumbs(['ARCHIVE','휴지통']);
    const items = state.guides.filter(g=>g.deleted);
    ui.main.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">ADMIN / TRASH</div><h1 class="page-title">휴지통</h1><p class="page-description">삭제한 공략은 여기에서 복구할 수 있습니다. 로컬 프로토타입에서는 물리 삭제하지 않습니다.</p></div></div>
      <section class="surface"><div class="section-head"><h2>삭제된 공략</h2><span class="count-badge">${items.length}</span></div>
      <div class="trash-list">${items.length?items.map(g=>`<div class="trash-item"><div class="trash-item-copy"><div class="trash-item-title">${escapeHtml(g.title)} ${g.variant?`· ${escapeHtml(g.variant)}`:''}</div><div class="trash-item-meta">${escapeHtml(state.categories[g.category]?.name||g.category)} · ${escapeHtml(g.group||'')}</div></div><button class="button small" type="button" data-action="restore-guide" data-guide="${escapeHtml(g.id)}">복구</button></div>`).join(''):'<div class="empty-state">휴지통이 비어 있습니다.</div>'}</div></section>`;
  }

  function render() {
    renderNav();
    document.body.classList.toggle('edit-mode', editMode);
    ui.editToggle.setAttribute('aria-pressed', String(editMode));
    ui.editToggleText.textContent = editMode ? '편집 모드 ON' : '편집 모드';
    ui.modePill.innerHTML = `<span class="status-dot"></span><span>${editMode?'편집 모드':'보기 모드'}</span>`;
    const route = getRoute();
    if (route.type === 'heroes') renderHeroes();
    else if (route.type === 'hero') renderHeroDetail(route.name);
    else if (route.type === 'category') { renderCategory(route.category); }
    else if (route.type === 'pvp') { renderPvp(); }
    else if (route.type === 'daily') { renderDaily(); }
    else if (route.type === 'coupons') { renderCoupons(); }
    else if (route.type === 'guide') {
      const g = state.guides.find(x=>x.id===route.id && !x.deleted);
      if (!g) routeTo('#heroes');
      else if (g.category === 'pvp') { pvpOpenGuideId = g.id; renderPvp(); }
      else { renderCategory(g.category, g.id); }
    }
    else if (route.type === 'trash') renderTrash();
  }

  function renameHero(oldName) {
    const next = prompt('새 캐릭터명을 입력하세요.', oldName)?.trim();
    if (!next || next === oldName) return;
    if (state.heroProfiles[next]) { alert('이미 같은 이름의 캐릭터가 있습니다.'); return; }
    state.heroProfiles[next] = state.heroProfiles[oldName];
    delete state.heroProfiles[oldName];
    const idx = state.heroOrder.indexOf(oldName);
    if (idx >= 0) state.heroOrder[idx] = next;
    if (state.portraits[oldName]) { state.portraits[next] = state.portraits[oldName]; delete state.portraits[oldName]; }
    state.guides.forEach(g => { g.heroes = (g.heroes||[]).map(h => h===oldName ? next : h); });
    markDirty();
    routeTo(`#hero/${encodeURIComponent(next)}`);
  }

  function addGuide(category) {
    const c = state.categories[category];
    const title = prompt(`${c.name} 공략명을 입력하세요.`)?.trim();
    if (!title) return;
    const variant = prompt('버전/구분을 입력하세요. 없으면 비워두세요.', '')?.trim() || '';
    const heroesRaw = prompt('영웅명을 쉼표(,)로 구분해서 입력하세요.', '') || '';
    const heroes = heroesRaw.split(',').map(v=>v.trim()).filter(Boolean);
    heroes.forEach(h => {
      if (!state.heroProfiles[h]) {
        state.heroProfiles[h] = {basicSetup:'미등록',exclusiveEquipment:'미등록',transcendence:'미등록',notes:'미등록'};
        state.heroOrder.push(h);
      }
    });
    const maxOrder = Math.max(0,...state.guides.filter(g=>g.category===category).map(g=>g.order||0));
    const id = `${category}-custom-${Date.now()}`;
    state.guides.push({id,category,group:title,boss:title,variant,title,order:maxOrder+10,sourceImage:'',skillImage:'',heroes,tags:[c.name,title,variant].filter(Boolean),details:{pets:[],altPets:[],rows:heroes.map(hero=>({hero,formation:'',weapon:[],armor:[],accessory:'',alternative:'',sub:'',speed:'',comment:''}))}});
    markDirty();
    routeTo(`#guide/${id}`);
  }

  function editGuideHeroes(id) {
    const g = state.guides.find(x=>x.id===id); if (!g) return;
    const raw = prompt('영웅명을 쉼표(,)로 구분해서 입력하세요.', (g.heroes||[]).join(', '));
    if (raw === null) return;
    const heroes = raw.split(',').map(v=>v.trim()).filter(Boolean);
    g.heroes = heroes;
    const previousRows = g.details?.rows || [];
    g.details ||= {};
    g.details.rows = heroes.map((h, i) => previousRows.find(r => r.hero === h) || previousRows[i] || {hero:h,formation:'',weapon:[],armor:[],accessory:'',alternative:'',sub:'',speed:'',comment:''});
    g.details.rows.forEach((r,i)=>r.hero=heroes[i]);
    heroes.forEach(h => {
      if (!state.heroProfiles[h]) {
        state.heroProfiles[h] = {basicSetup:'미등록',exclusiveEquipment:'미등록',transcendence:'미등록',notes:'미등록'};
        state.heroOrder.push(h);
      }
    });
    markDirty(); render();
  }

  function replaceHeroPortrait(name) {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = () => {
      const file = input.files?.[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = () => { state.portraits[name] = reader.result; markDirty(); renderHeroDetail(name); };
      reader.readAsDataURL(file);
    };
    input.click();
  }

  function replaceImage(id, kind) {
    const input = document.querySelector(`[data-file-input="${CSS.escape(id)}-${kind}"]`);
    if (!input) return;
    input.value = '';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const g = state.guides.find(x=>x.id===id); if (!g) return;
        if (kind === 'source') g.sourceImageOverride = reader.result;
        else if (kind.startsWith('skill-seq-')) {
          const index = Number(kind.replace('skill-seq-',''));
          if (Number.isInteger(index) && g.skillSequence?.[index]) g.skillSequence[index].imageOverride = reader.result;
        } else g.skillImageOverride = reader.result;
        markDirty(); render();
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }

  function resetGuideImages(id) {
    const g = state.guides.find(x=>x.id===id); if (!g) return;
    delete g.sourceImageOverride; delete g.skillImageOverride;
    if (Array.isArray(g.skillSequence)) g.skillSequence.forEach(step => delete step.imageOverride);
    markDirty(); render();
  }

  function reorderGuides(dragId, targetId) {
    if (dragId === targetId) return;
    const drag = state.guides.find(g=>g.id===dragId), target = state.guides.find(g=>g.id===targetId);
    if (!drag || !target || drag.category !== target.category) return;
    const arr = state.guides.filter(g=>g.category===drag.category && !g.deleted).sort((a,b)=>a.order-b.order);
    const from = arr.findIndex(g=>g.id===dragId), to = arr.findIndex(g=>g.id===targetId);
    if (from<0||to<0) return;
    const [moved]=arr.splice(from,1); arr.splice(to,0,moved);
    arr.forEach((g,i)=>g.order=(i+1)*10);
    markDirty(); render();
  }

  function reorderHeroes(dragName,targetName) {
    if (dragName===targetName) return;
    const arr=state.heroOrder; const from=arr.indexOf(dragName),to=arr.indexOf(targetName);
    if(from<0||to<0)return; const [m]=arr.splice(from,1); arr.splice(to,0,m); markDirty(); renderHeroes();
  }

  function openImage(src,title='이미지') {
    if (!src) return;
    modalZoom=100;
    ui.modalImage.src=src;
    ui.modalImage.style.width='100%';
    ui.modalTitle.textContent=title;
    ui.zoomLabel.textContent='100%';
    ui.modal.classList.remove('hidden');
    document.body.style.overflow='hidden';
  }

  function closeModal(){ ui.modal.classList.add('hidden'); document.body.style.overflow=''; }
  function setZoom(next){ modalZoom=Math.max(50,Math.min(300,next)); ui.modalImage.style.width=`${modalZoom}%`; ui.zoomLabel.textContent=`${modalZoom}%`; }

  function renderSearch(query) {
    const q=query.trim().toLowerCase();
    if(!q){ui.searchResults.classList.add('hidden');ui.searchResults.innerHTML='';return;}
    const heroResults=state.heroOrder.filter(h=>h.toLowerCase().includes(q) || (state.heroRoles?.[h]||'').toLowerCase().includes(q) || getHeroUses(h).some(g=>(`${g.title} ${g.variant} ${g.boss}`).toLowerCase().includes(q))).slice(0,6);
    const guideResults=state.guides.filter(g=>!g.deleted && [g.title,g.variant,g.group,g.boss,...(g.heroes||[]),...(g.tags||[])].join(' ').toLowerCase().includes(q)).slice(0,8);
    const html=[
      ...heroResults.map(h=>`<div class="search-result" data-route="#hero/${encodeURIComponent(h)}">${portrait(h)?`<img class="search-result-avatar" src="${portrait(h)}" alt="">`:`<div class="search-result-icon">♙</div>`}<div class="search-result-copy"><div class="search-result-title">${escapeHtml(h)}</div><div class="search-result-meta">캐릭터 · ${escapeHtml(state.heroRoles?.[h] || '미분류')} · PVE 사용처 ${getHeroUses(h).length}개</div></div></div>`),
      ...guideResults.map(g=>`<div class="search-result" data-route="#guide/${encodeURIComponent(g.id)}"><div class="search-result-icon" style="color:${state.categories[g.category].accent}">${state.categories[g.category].icon}</div><div class="search-result-copy"><div class="search-result-title">${escapeHtml(g.title)}${g.variant?` · ${escapeHtml(g.variant)}`:''}</div><div class="search-result-meta">${escapeHtml(state.categories[g.category].name)} · ${(g.heroes||[]).map(escapeHtml).join(' / ')}</div></div></div>`)
    ].join('');
    ui.searchResults.innerHTML=html || '<div class="search-empty">검색 결과가 없습니다.</div>';
    ui.searchResults.classList.remove('hidden');
  }

  document.addEventListener('click', (e) => {
    const routeEl=e.target.closest('[data-route]');
    if(routeEl){routeTo(routeEl.dataset.route);ui.search.value='';ui.searchResults.classList.add('hidden');return;}
    const heroRoleFilter=e.target.closest('[data-hero-role-filter]');
    if(heroRoleFilter){
      const y=window.scrollY;
      localHeroRoleFilter=heroRoleFilter.dataset.heroRoleFilter || '전체';
      renderHeroes();
      requestAnimationFrame(()=>window.scrollTo(0,y));
      return;
    }
    const filter=e.target.closest('[data-category-filter]');
    if(filter){
      currentCategoryFilter=filter.dataset.categoryFilter;
      const r=getRoute();
      const cat=r.type==='guide'?state.guides.find(g=>g.id===r.id)?.category:r.category;
      const candidates=state.guides.filter(g=>!g.deleted && g.category===(cat||'siege') && g.group===currentCategoryFilter).sort((a,b)=>a.order-b.order);
      const remembered=guideTabs[`${cat||'siege'}|${currentCategoryFilter}`];
      const target=candidates.find(g=>g.id===remembered) || candidates[0];
      if(target) routeTo(`#guide/${encodeURIComponent(target.id)}`); else renderCategory(cat||'siege');
      return;
    }
    const guideTab=e.target.closest('[data-guide-tab]');
    if(guideTab){
      const id=guideTab.dataset.guideTab;
      const g=state.guides.find(x=>x.id===id && !x.deleted);
      if(g){guideTabs[`${g.category}|${g.group}`]=g.id; currentCategoryFilter=g.group; routeTo(`#guide/${encodeURIComponent(g.id)}`);} 
      return;
    }
    const open=e.target.closest('[data-open-image]');
    if(open){openImage(open.dataset.openImage,open.dataset.imageTitle||'이미지');return;}
    const pvpButton=e.target.closest('[data-pvp-open]');
    if(pvpButton){
      const y=window.scrollY;
      const id=pvpButton.dataset.pvpOpen;
      pvpOpenGuideId = pvpOpenGuideId===id ? '' : id;
      renderPvp();
      requestAnimationFrame(()=>window.scrollTo(0,y));
      return;
    }
    const couponButton=e.target.closest('[data-copy-coupon-index]');
    if(couponButton){
      const idx=Number(couponButton.dataset.copyCouponIndex);
      const code=state.couponCodes?.[idx]?.code || '';
      if(!code){showToast('복사할 쿠폰 코드가 없습니다.','warn');return;}
      copyText(code).then(()=>{couponButton.textContent='복사됨';showToast(`${code} 복사 완료`,'success');setTimeout(()=>couponButton.textContent='복사',1200);}).catch(()=>showToast('복사에 실패했습니다. 코드를 직접 선택해 주세요.','warn'));
      return;
    }
    const settingColor=e.target.closest('[data-setting-color][data-setting-row]');
    if(settingColor && editMode){
      const card=settingColor.closest('[data-guide-id]');
      const g=state.guides.find(x=>x.id===card?.dataset.guideId);
      const ri=Number(settingColor.dataset.settingRow);
      const field=settingColor.dataset.settingColorField || 'alternative';
      if(g && g.details?.rows?.[ri]){
        const r=g.details.rows[ri]; r.colors ||= {}; r.colors[field]=settingColor.dataset.settingColor;
        markDirty(); render(); showToast('셀 색상을 변경했습니다.','success');
      }
      return;
    }
    const externalLink=e.target.closest('.utility-external-link');
    if(externalLink && editMode){
      e.preventDefault();
      showToast('편집 모드에서는 링크 이동을 막았습니다. 편집을 종료하면 열 수 있습니다.');
      return;
    }
    const action=e.target.closest('[data-action]');
    if(action){
      const a=action.dataset.action;
      if(a==='reset-source') resetToSource();
      else if(a==='rename-hero') renameHero(action.dataset.hero);
      else if(a==='replace-hero-portrait') replaceHeroPortrait(action.dataset.hero);
      else if(a==='add-guide') addGuide(action.dataset.category);
      else if(a==='edit-heroes') editGuideHeroes(action.dataset.guide);
      else if(a==='replace-image') replaceImage(action.dataset.guide,action.dataset.kind);
      else if(a==='reset-images') resetGuideImages(action.dataset.guide);
      else if(a==='delete-guide'){const g=state.guides.find(x=>x.id===action.dataset.guide);if(g&&confirm(`'${g.title}${g.variant?` · ${g.variant}`:''}' 공략을 휴지통으로 이동할까요?`)){g.deleted=true;markDirty();render();}}
      else if(a==='restore-guide'){const g=state.guides.find(x=>x.id===action.dataset.guide);if(g){g.deleted=false;markDirty();renderTrash();renderNav();}}
      else if(a==='add-coupon'){
        state.couponCodes.push({code:'새 쿠폰 코드',reward:'보상 내용',note:''});
        const i=state.couponCodes.length-1; markDirty(); renderCoupons();
        requestAnimationFrame(()=>{const el=document.querySelector(`[data-coupon-field="code"][data-coupon-index="${i}"]`); if(el){el.focus(); const r=document.createRange();r.selectNodeContents(el);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);}});
      }
      else if(a==='delete-coupon'){const i=Number(action.dataset.couponIndex);if(Number.isInteger(i)&&state.couponCodes[i]&&confirm(`'${state.couponCodes[i].code}' 쿠폰을 삭제할까요?`)){state.couponCodes.splice(i,1);markDirty();renderCoupons();}}
      return;
    }
    if(!e.target.closest('.global-search-wrap')) ui.searchResults.classList.add('hidden');
  });

  document.addEventListener('input', e => {
    const utilityField=e.target.closest('[data-utility-page][data-utility-field]');
    if(utilityField && editMode){
      const page=utilityField.dataset.utilityPage, field=utilityField.dataset.utilityField;
      if(state.utilityPages?.[page]){state.utilityPages[page][field]=utilityField.innerText.trim();markDirty();}
      return;
    }
    const utilityUrl=e.target.closest('[data-utility-url-page]');
    if(utilityUrl && editMode){
      const page=utilityUrl.dataset.utilityUrlPage;
      if(state.utilityPages?.[page]){state.utilityPages[page].buttonUrl=utilityUrl.value.trim();markDirty();}
      return;
    }
    const couponField=e.target.closest('[data-coupon-field][data-coupon-index]');
    if(couponField && editMode){
      const i=Number(couponField.dataset.couponIndex), field=couponField.dataset.couponField;
      if(Number.isInteger(i)&&state.couponCodes?.[i]){state.couponCodes[i][field]=couponField.innerText.trim();markDirty();}
      return;
    }
    const heroField=e.target.closest('[data-hero-field]');
    if(heroField && editMode){const name=heroField.dataset.hero, field=heroField.dataset.heroField;if(state.heroProfiles[name]){state.heroProfiles[name][field]=heroField.innerText.trim()||'미등록';markDirty();}return;}
    const settingField=e.target.closest('[data-setting-field]');
    if(settingField && editMode){
      const card=settingField.closest('[data-guide-id]');
      const g=state.guides.find(x=>x.id===card?.dataset.guideId);
      const ri=Number(settingField.dataset.settingRow);
      if(g && g.details?.rows?.[ri]){
        const r=g.details.rows[ri], field=settingField.dataset.settingField;
        const value=settingField.innerText.trim().replace(/^—$/,'');
        if(field==='weapon' || field==='armor'){
          const oi=Number(settingField.dataset.settingOption); r[field] ||= []; r[field][oi]=value;
        } else if(field==='hero'){
          const old=r.hero; r.hero=value || old; g.heroes[ri]=r.hero;
          if(r.hero && !state.heroProfiles[r.hero]){state.heroProfiles[r.hero]={basicSetup:'미등록',exclusiveEquipment:'미등록',transcendence:'미등록',notes:'미등록'};state.heroOrder.push(r.hero);}
        } else r[field]=value;
        if(field==='alternative'){
          settingField.classList.toggle('muted', !value);
          const td=settingField.closest('.alternative-cell');
          if(td) td.classList.toggle('has-alt', !!value);
        }
        markDirty();
      }
      return;
    }
    const metaField=e.target.closest('[data-guide-meta-field]');
    if(metaField && editMode){
      const card=metaField.closest('[data-guide-id]'); const g=state.guides.find(x=>x.id===card?.dataset.guideId);
      if(g){const field=metaField.dataset.guideMetaField;g.details ||= {};g.details[field]=metaField.innerText.split(',').map(v=>v.trim()).filter(v=>v && v!=='미등록');markDirty();}
      return;
    }
    const guideField=e.target.closest('[data-guide-field]');
    if(guideField && editMode){const card=guideField.closest('[data-guide-id]');const g=state.guides.find(x=>x.id===card?.dataset.guideId);if(g){const field=guideField.dataset.guideField;g[field]=guideField.innerText.trim();if(field==='group')g.boss=g.group;markDirty();}return;}
  });

  document.addEventListener('change', e => {
    const formationSelect = e.target.closest('[data-formation-select]');
    if (formationSelect && editMode) {
      const card = formationSelect.closest('[data-guide-id]');
      const g = state.guides.find(x => x.id === card?.dataset.guideId);
      if (!g) return;
      g.details ||= {};
      g.details.formationType = formationSelect.value;
      const frontCount = { '보호진형':4, '밸런스진형':3, '기본진형':2, '공격진형':1 }[formationSelect.value];
      if (frontCount && Array.isArray(g.details.rows)) {
        g.details.rows.forEach((row, index) => { row.formation = index < frontCount ? '앞줄' : '뒷줄'; });
      }
      markDirty();
      render();
      showToast(formationSelect.value ? `${formationSelect.value}으로 변경했습니다.` : '진형을 자동 판정으로 변경했습니다.', 'success');
      return;
    }
  });

  document.addEventListener('dragstart', e => {
    if(!editMode)return;
    const guide=e.target.closest('[data-guide-id]'); if(guide){draggingGuide=guide.dataset.guideId;e.dataTransfer.effectAllowed='move';return;}
    const hero=e.target.closest('[data-hero]'); if(hero){draggingHero=hero.dataset.hero;e.dataTransfer.effectAllowed='move';}
  });
  document.addEventListener('dragover', e => {if(editMode && (e.target.closest('[data-guide-id]')||e.target.closest('[data-hero]')))e.preventDefault();});
  document.addEventListener('drop', e => {if(!editMode)return;const guide=e.target.closest('[data-guide-id]');if(guide&&draggingGuide){e.preventDefault();reorderGuides(draggingGuide,guide.dataset.guideId);draggingGuide=null;return;}const hero=e.target.closest('[data-hero]');if(hero&&draggingHero){e.preventDefault();reorderHeroes(draggingHero,hero.dataset.hero);draggingHero=null;}});
  document.addEventListener('dragend',()=>{draggingGuide=null;draggingHero=null;});

  ui.editToggle.addEventListener('click',()=>{
    if(!editMode){
      const password=prompt('편집 비밀번호를 입력하세요.');
      if(password===null)return;
      if(password.trim()!==EDIT_PASSWORD){alert('비밀번호가 올바르지 않습니다.');return;}
      editMode=true;
      render();
      showToast('편집 모드를 시작했습니다.','success');
      return;
    }
    if(dirty){const ok=confirm('저장되지 않은 변경사항이 있습니다. 변경사항을 유지한 채 편집 모드를 종료할까요?');if(!ok)return;}
    editMode=false;
    render();
  });
  ui.trashNav.addEventListener('click',()=>routeTo('#trash'));
  ui.saveButton.addEventListener('click',saveState);
  ui.discardButton.addEventListener('click',discardChanges);
  ui.search.addEventListener('compositionstart',()=>{globalSearchComposing=true;});
  ui.search.addEventListener('compositionend',e=>{globalSearchComposing=false;renderSearch(e.target.value);});
  ui.search.addEventListener('input',e=>{if(globalSearchComposing||e.isComposing)return;renderSearch(e.target.value);});
  ui.search.addEventListener('focus',e=>renderSearch(e.target.value));
  ui.menuButton.addEventListener('click',()=>document.body.classList.toggle('sidebar-open'));
  ui.scrim.addEventListener('click',()=>document.body.classList.remove('sidebar-open'));
  ui.modalClose.addEventListener('click',closeModal);
  ui.zoomIn.addEventListener('click',()=>setZoom(modalZoom+25));
  ui.zoomOut.addEventListener('click',()=>setZoom(modalZoom-25));
  ui.modal.addEventListener('click',e=>{if(e.target===ui.modal)closeModal();});

  document.querySelector('.brand').addEventListener('click',()=>routeTo('#heroes'));
  document.querySelector('.brand').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();routeTo('#heroes');}});

  window.addEventListener('hashchange',render);
  window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
  document.addEventListener('keydown',e=>{
    if(e.key==='/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName) && !document.activeElement.isContentEditable){e.preventDefault();ui.search.focus();}
    if(e.key==='Escape'){if(!ui.modal.classList.contains('hidden'))closeModal();else{ui.searchResults.classList.add('hidden');document.body.classList.remove('sidebar-open');}}
  });

  render();
})();
